
<?php
header('Content-Type: application/json');

$apiKey = 'TON_API_KEY_ICI'; // Remplace par ta clé OpenAI

$data = json_decode(file_get_contents("php://input"), true);
$question = $data['message'] ?? '';

$response = file_get_contents("https://api.openai.com/v1/chat/completions", false, stream_context_create([
    'http' => [
        'method'  => 'POST',
        'header'  => "Content-Type: application/json\r\n" .
                     "Authorization: Bearer $apiKey\r\n",
        'content' => json_encode([
            "model" => "gpt-3.5-turbo",
            "messages" => [
                ["role" => "system", "content" => "Tu es un assistant pour un site e-commerce togolais nommé Appo Word."],
                ["role" => "user", "content" => $question]
            ]
        ])
    ]
]));

echo $response;
?>
