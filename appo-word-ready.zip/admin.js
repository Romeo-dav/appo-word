
const form = document.getElementById('loginForm');
const adminPanel = document.getElementById('adminPanel');

form.addEventListener('submit', function(e) {
    e.preventDefault();
    const user = document.getElementById('username').value;
    const pass = document.getElementById('password').value;

    if (user === 'admin' && pass === 'admin123') {
        alert('Connexion réussie');
        form.style.display = 'none';
        adminPanel.style.display = 'block';
    } else {
        alert('Identifiants incorrects');
    }
});
