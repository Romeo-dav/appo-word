
const chatInput = document.getElementById('chat-input');
const chatMessages = document.getElementById('chat-messages');

chatInput.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && chatInput.value.trim() !== '') {
        const question = chatInput.value.trim();
        ajouterMessage("Vous", question);
        repondre(question);
        chatInput.value = '';
    }
});

function ajouterMessage(auteur, texte) {
    const msg = document.createElement('div');
    msg.innerHTML = `<strong>${auteur} :</strong> ${texte}`;
    chatMessages.appendChild(msg);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function repondre(question) {
    ajouterMessage("Appo Bot", "⏳ Réflexion...");

    fetch('chatgpt.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ message: question })
    })
    .then(res => res.json())
    .then(data => {
        const reply = data.choices[0].message.content;
        ajouterMessage("Appo Bot", reply);
    })
    .catch(err => {
        console.error(err);
        ajouterMessage("Appo Bot", "❌ Erreur de connexion à l'IA.");
    });
}
